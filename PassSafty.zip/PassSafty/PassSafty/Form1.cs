﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
namespace PassSafty
{
    public partial class Form1 : Form
    {
        Timer timer = new Timer(); String salt1 = BCrypt.Net.BCrypt.GenerateSalt(16); byte[] salt2 = new byte[] { 56, 4, 34, 38, 7, 41, 40, 33, 18, 8, 22, 19, 91, 97, 68, 14, 71, 88, 90, 15, 25, 48, 61, 29, 27 };
        public Form1()
        {
            InitializeComponent(); textBox4.Select();
            if (File.Exists("lkez.asen") == false)
            {
                label8.Text = "Program is slow to provide better security. Password is '12345'.";
                Properties.Settings.Default.tex = Random(2048); Properties.Settings.Default.fil = Random(2048); Properties.Settings.Default.set1 = Random(2048); Properties.Settings.Default.set2 = BCrypt.Net.BCrypt.HashPassword("12345", salt1); Properties.Settings.Default.set3 = Random(2048); File.Create("lkez.asen").Close(); EncryptFile(); Properties.Settings.Default.tex = EncryptText(Properties.Settings.Default.tex, "12345" + Properties.Settings.Default.set1 + Properties.Settings.Default.set3); Properties.Settings.Default.fil = EncryptText(Properties.Settings.Default.fil, Properties.Settings.Default.set1 + Properties.Settings.Default.set3 + "12345"); Properties.Settings.Default.set1 = EncryptText(Properties.Settings.Default.set1, "12345"); Properties.Settings.Default.set3 = EncryptText(Properties.Settings.Default.set3, "12345"); Properties.Settings.Default.Save();
            }
        }

        private byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
        {
            byte[] encryptedBytes = null;
            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    var key = new Rfc2898DeriveBytes(passwordBytes, salt2, 10000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);
                    AES.Mode = CipherMode.CBC;
                    using (var cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
                        cs.Close();
                    }
                    encryptedBytes = ms.ToArray();
                }
            }
            return encryptedBytes;
        }
        private void EncryptFile()
        {
            String file = "lkez.asen";
            byte[] bytesToBeEncrypted = File.ReadAllBytes(file);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(Properties.Settings.Default.fil);
            passwordBytes = SHA512.Create().ComputeHash(passwordBytes);
            byte[] bytesEncrypted = AES_Encrypt(bytesToBeEncrypted, passwordBytes);
            String fileEncrypted = "lkez.asen";
            File.WriteAllBytes(fileEncrypted, bytesEncrypted);
        }
        private String EncryptText(String input, String password)
        {
            byte[] baPwd = Encoding.UTF8.GetBytes(password);
            byte[] baPwdHash = SHA512Managed.Create().ComputeHash(baPwd);
            byte[] baText = Encoding.UTF8.GetBytes(input);
            byte[] baSalt = GetRandomBytes();
            byte[] baEncrypted = new byte[baSalt.Length + baText.Length];
            for (int i = 0; i < baSalt.Length; i++)
                baEncrypted[i] = baSalt[i];
            for (int i = 0; i < baText.Length; i++)
                baEncrypted[i + baSalt.Length] = baText[i];
            baEncrypted = AES_Encrypt(baEncrypted, baPwdHash);
            String result = Convert.ToBase64String(baEncrypted);
            return result;
        }
        private byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes = null;
            using (MemoryStream ms = new MemoryStream())
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    var key = new Rfc2898DeriveBytes(passwordBytes, salt2, 10000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);
                    AES.Mode = CipherMode.CBC;
                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = ms.ToArray();
                }
            }
            return decryptedBytes;
        }
        private void DecryptFile()
        {
            String fileEncrypted = "lkez.asen";
            byte[] bytesToBeDecrypted = File.ReadAllBytes(fileEncrypted);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(Properties.Settings.Default.fil);
            passwordBytes = SHA512.Create().ComputeHash(passwordBytes);
            byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);
            String file = "lkez.asen";
            File.WriteAllBytes(file, bytesDecrypted);
        }
        private String DecryptText(String input, String password)
        {
            byte[] baPwd = Encoding.UTF8.GetBytes(password);
            byte[] baPwdHash = SHA512Managed.Create().ComputeHash(baPwd);
            byte[] baText = Convert.FromBase64String(input);
            byte[] baDecrypted = AES_Decrypt(baText, baPwdHash);
            int saltLength = GetSaltLength();
            byte[] baResult = new byte[baDecrypted.Length - saltLength];
            for (int i = 0; i < baResult.Length; i++)
                baResult[i] = baDecrypted[i + saltLength];
            String result = Encoding.UTF8.GetString(baResult);
            return result;
        }

        private void Save()
        {
            Properties.Settings.Default.tex = Random(2048);
            using (StreamWriter w = new StreamWriter("lkez.asen")) { foreach (var item in listBox1.Items) { w.WriteLineAsync(EncryptText(item.ToString(), Properties.Settings.Default.tex)); } }
        }
        private static String Random(int length)
        {
            const String valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890`~!@#$%^&*_-+=[]{}'<>/?:;.,";
            StringBuilder res = new StringBuilder();
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] uintBuffer = new byte[sizeof(uint)];

                while (length-- > 0)
                {
                    rng.GetBytes(uintBuffer);
                    uint num = BitConverter.ToUInt32(uintBuffer, 0);
                    res.Append(valid[(int)(num % (uint)valid.Length)]);
                }
            }
            return res.ToString();
        }
        private static int GetSaltLength()
        {
            return 25;
        }
        private static byte[] GetRandomBytes()
        {
            int saltLength = GetSaltLength();
            byte[] ba = new byte[saltLength];
            RNGCryptoServiceProvider.Create().GetBytes(ba);
            return ba;
        }
        private void timer_Tick1(object sender, EventArgs e)
        {
            button4.Enabled = true;
            textBox4.Enabled = true;
            label8.Visible = false;
            timer.Stop();
        }
        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            while (listBox1.SelectedItems.Count > 0)
            {
                String edit = listBox1.SelectedItem.ToString();
                String[] splits = Array.ConvertAll(edit.Split(':'), p => p.Trim());
                textBox1.Text = splits[0]; textBox2.Text = splits[1]; textBox3.Text = splits[2];
                listBox1.Items.Remove(listBox1.SelectedItems[0]);
            }
        }
        private void Worker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Invoke(new Action(() => button4.Enabled = false));
            Invoke(new Action(() => textBox4.Enabled = false));
            Invoke(new Action(() => label8.Text = "Please Wait! Checking Credentials."));
            bool value = BCrypt.Net.BCrypt.Verify(textBox4.Text, Properties.Settings.Default.set2);
            if (value)
            {
                Invoke(new Action(() => label8.Text = "Please Wait! Displaying Secure Information.")); Properties.Settings.Default.lkez = textBox4.Text; Properties.Settings.Default.set1 = DecryptText(Properties.Settings.Default.set1, Properties.Settings.Default.lkez); Properties.Settings.Default.set3 = DecryptText(Properties.Settings.Default.set3, Properties.Settings.Default.lkez); Properties.Settings.Default.tex = DecryptText(Properties.Settings.Default.tex, Properties.Settings.Default.lkez + Properties.Settings.Default.set1 + Properties.Settings.Default.set3);
                Properties.Settings.Default.fil = DecryptText(Properties.Settings.Default.fil, Properties.Settings.Default.set1 + Properties.Settings.Default.set3 + Properties.Settings.Default.lkez); DecryptFile(); String item;
                using (StreamReader r = new StreamReader("lkez.asen"))
                {
                    while ((item = r.ReadLine()) != null)
                    {
                        Invoke(new Action(() => listBox1.Items.Add(DecryptText(item, Properties.Settings.Default.tex))));
                    }
                    Invoke(new Action(() => panel1.Hide())); Invoke(new Action(() => textBox1.Select()));
                }
            }
            else
            {
                Invoke(new Action(() => timer.Interval = 30000)); Invoke(new Action(() => timer.Tick += timer_Tick1)); Invoke(new Action(() => timer.Start())); Invoke(new Action(() => label8.Text = "Wrong Information! Locked For 30 Seconds!"));
            }
        }
        private void Worker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Invoke(new Action(() => textBox5.Enabled = false)); Invoke(new Action(() => textBox6.Enabled = false)); Invoke(new Action(() => textBox7.Enabled = false)); Invoke(new Action(() => button5.Enabled = false)); Invoke(new Action(() => button5.Text = "Restarting!")); bool value = BCrypt.Net.BCrypt.Verify(textBox4.Text, Properties.Settings.Default.set2) & textBox6.Text == textBox7.Text; 
            if (value)
            {
                 Properties.Settings.Default.lkez = textBox6.Text; Properties.Settings.Default.set2 = BCrypt.Net.BCrypt.HashPassword(textBox6.Text, salt1); Invoke(new Action(() => Dispose()));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox1.Text + "  :  " + textBox2.Text + "  :  " + textBox3.Text);
            textBox1.Clear(); textBox2.Clear(); textBox3.Clear();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            while (listBox1.SelectedItems.Count > 0)
            {
                listBox1.Items.Remove(listBox1.SelectedItems[0]);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Worker.RunWorkerAsync();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Worker1.RunWorkerAsync();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(listBox1.SelectedItem.ToString());
            }
            catch (Exception) { }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            panel2.BringToFront();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            textBox5.Clear(); textBox6.Clear(); textBox7.Clear(); panel2.SendToBack();
        }
        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Worker.RunWorkerAsync();
                e.SuppressKeyPress = true;
            }
        }
    }
}